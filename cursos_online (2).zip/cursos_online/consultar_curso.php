
<?php
require_once('cabecalho.php');
require_once('conexao.php');

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $sql = "SELECT * FROM cursos WHERE id_curso = $id";
    $resultado = mysqli_query($conn, $sql);

    if ($r = mysqli_fetch_assoc($resultado)) {
?>

<h2>Consultar Curso</h2>

<p><strong>ID:</strong> <?= $r['id_curso'] ?></p>
<p><strong>Nome:</strong> <?= $r['nome'] ?></p>
<p><strong>Descrição:</strong> <?= $r['descricao'] ?></p>
<p><strong>Carga Horária:</strong> <?= $r['carga_horaria'] ?></p>
<p><strong>Ativo:</strong> <?= $r['ativo'] ? 'Sim' : 'Não' ?></p>

<a href="cursos.php" class="btn btn-secondary">Voltar</a>

<?php
    } else {
        echo "Curso não encontrado.";
    }

} else {
    echo "ID não informado.";
}
?>

<?php require_once('rodape.php'); ?>

