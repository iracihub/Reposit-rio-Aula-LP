
<?php
require_once('cabecalho.php');
require_once('conexao.php');

// Buscar alunos, cursos e professores
$sql_alunos = "SELECT * FROM alunos";
$result_alunos = mysqli_query($conn, $sql_alunos);

$sql_cursos = "SELECT * FROM cursos";
$result_cursos = mysqli_query($conn, $sql_cursos);

$sql_professores = "SELECT * FROM professores";
$result_professores = mysqli_query($conn, $sql_professores);
?>

<h2>Nova Matrícula</h2>

<form method="post">

    <div class="mb-3">
        <label>Aluno</label>
        <select name="aluno" class="form-select" required>
            <?php while ($a = mysqli_fetch_assoc($result_alunos)): ?>
                <option value="<?= $a['id_aluno'] ?>"><?= $a['nome'] ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Curso</label>
        <select name="curso" class="form-select" required>
            <?php while ($c = mysqli_fetch_assoc($result_cursos)): ?>
                <option value="<?= $c['id_curso'] ?>"><?= $c['nome'] ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Professor</label>
        <select name="professor" class="form-select" required>
            <?php while ($p = mysqli_fetch_assoc($result_professores)): ?>
                <option value="<?= $p['id_professor'] ?>"><?= $p['nome'] ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-select" required>
            <option value="Em curso">Em curso</option>
            <option value="Concluído">Concluído</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
    <a href="matriculas.php" class="btn btn-secondary">Voltar</a>

</form>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $aluno = $_POST['aluno'];
    $curso = $_POST['curso'];
    $professor = $_POST['professor'];
    $status = $_POST['status'];

    // Data automática
    $data = date('Y-m-d');

    $sql = "INSERT INTO matriculas (id_aluno, id_curso, id_professor, data_matricula, status)
            VALUES ('$aluno', '$curso', '$professor', '$data', '$status')";

    if (mysqli_query($conn, $sql)) {
        echo "<p>Matrícula realizada com sucesso!</p>";
    } else {
        echo "Erro: " . mysqli_error($conn);
    }
}
?>

<?php require_once('rodape.php'); ?>
