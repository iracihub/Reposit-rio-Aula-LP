<?php
require_once('cabecalho.php');
require_once('conexao.php');

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $especialidade = $_POST['especialidade'];

    $sql = "INSERT INTO professores (nome, email, especialidade)
            VALUES ('$nome', '$email', '$especialidade')";

    if (mysqli_query($conn, $sql)) {
        // REDIRECIONA após salvar (ESSENCIAL )
        header("Location: professores.php");
        exit;
    } else {
        echo "Erro: " . mysqli_error($conn);
    }
}
?>

<h2>Novo Professor</h2>

<form method="POST">

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Especialidade</label>
        <input type="text" name="especialidade" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Cadastrar</button>
    <a href="professores.php" class="btn btn-secondary">Voltar</a>

</form>

<?php require_once('rodape.php'); ?>
