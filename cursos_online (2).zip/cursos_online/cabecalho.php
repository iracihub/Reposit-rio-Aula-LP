
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Cursos Online</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Cursos Online</a>

        <div class="collapse navbar-collapse">
            <ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link" href="alunos.php">Alunos</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="cursos.php">Cursos</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="professores.php">Professores</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="matriculas.php">Matrículas</a>
                </li>

            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
