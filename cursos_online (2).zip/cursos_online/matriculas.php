<?php
require_once('cabecalho.php');
require_once('conexao.php');

$sql = "SELECT 
            m.id_matricula,
            a.nome AS aluno,
            c.nome AS curso,
            p.nome AS professor,
            m.data_matricula,
            m.status
        FROM matriculas m
        JOIN alunos a ON m.id_aluno = a.id_aluno
        JOIN cursos c ON m.id_curso = c.id_curso
        JOIN professores p ON m.id_professor = p.id_professor";

$resultado = mysqli_query($conn, $sql);

if (!$resultado) {
    die("Erro: " . mysqli_error($conn));
}
?>

<h2>Matrículas</h2>

<a href="nova_matricula.php" class="btn btn-success mb-3">Nova Matrícula</a>

<table class="table table-hover table-striped">
<thead>
<tr>
    <th>ID</th>
    <th>Aluno</th>
    <th>Curso</th>
    <th>Professor</th>
    <th>Data</th>
    <th>Status</th>
</tr>
</thead>

<tbody>

<?php if (mysqli_num_rows($resultado) > 0): ?>
    <?php while ($m = mysqli_fetch_assoc($resultado)): ?>
    <tr>
        <td><?= $m['id_matricula'] ?></td>
        <td><?= $m['aluno'] ?></td>
        <td><?= $m['curso'] ?></td>
        <td><?= $m['professor'] ?></td>
        <td><?= $m['data_matricula'] ?></td>
        <td><?= $m['status'] ?></td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="6">Nenhuma matrícula encontrada</td>
    </tr>
<?php endif; ?>

</tbody>
</table>

<?php require_once('rodape.php'); ?>

