
<?php
require_once('cabecalho.php');
require_once('conexao.php');

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $sql = "SELECT * FROM professores WHERE id_professor = $id";
    $resultado = mysqli_query($conn, $sql);

    if ($r = mysqli_fetch_assoc($resultado)) {
?>

<h2>Consultar Professor</h2>

<p><strong>ID:</strong> <?= $r['id_professor'] ?></p>
<p><strong>Nome:</strong> <?= $r['nome'] ?></p>
<p><strong>Email:</strong> <?= $r['email'] ?></p>
<p><strong>Especialidade:</strong> <?= $r['especialidade'] ?></p>

<a href="professores.php" class="btn btn-secondary">Voltar</a>

<?php
    } else {
        echo "Professor não encontrado.";
    }

} else {
    echo "ID não informado.";
}
?>

<?php require_once('rodape.php'); ?>
