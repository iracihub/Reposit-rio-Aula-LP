
<?php
require_once('cabecalho.php');
require_once('conexao.php');
?>

<h2>Novo Aluno</h2>

<form method="post">

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Cadastrar</button>
    <a href="alunos.php" class="btn btn-secondary">Voltar</a>

</form>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nome = $_POST['nome'];
    $email = $_POST['email'];

    // Data automática
    $data = date('Y-m-d');

    $sql = "INSERT INTO alunos (nome, email, data_cadastro)
            VALUES ('$nome', '$email', '$data')";

    if (mysqli_query($conn, $sql)) {
        echo "<p>Aluno cadastrado com sucesso!</p>";
    } else {
        echo "Erro: " . mysqli_error($conn);
    }
}
?>

<?php require_once('rodape.php'); ?>
