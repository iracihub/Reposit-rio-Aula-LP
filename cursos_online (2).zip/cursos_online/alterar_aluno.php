<?php
require_once('cabecalho.php');
require_once('conexao.php');

// Verifica se o id foi passado
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: alunos.php');
    exit;
}

$id = intval($_GET['id']); // intval protege contra SQL injection básico

// Busca os dados atuais do aluno
$sql = "SELECT * FROM alunos WHERE id_aluno = $id";
$resultado = mysqli_query($conn, $sql);

if (!$resultado || mysqli_num_rows($resultado) == 0) {
    header('Location: alunos.php');
    exit;
}

$aluno = mysqli_fetch_assoc($resultado);

// Se o formulário foi enviado, atualiza
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];

    $sqlUpdate = "UPDATE alunos SET nome='$nome', email='$email' WHERE id_aluno=$id";
    mysqli_query($conn, $sqlUpdate);

    header('Location: alunos.php');
    exit;
}
?>

<h2>Editar Aluno</h2>

<!-- action com o id na URL para o POST não perdê-lo -->
<form method="POST" action="alterar_aluno.php?id=<?= $id ?>">
    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome" class="form-control" value="<?= htmlspecialchars($aluno['nome']) ?>">
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="text" name="email" class="form-control" value="<?= htmlspecialchars($aluno['email']) ?>">
    </div>

    <a href="alunos.php" class="btn btn-secondary">Cancelar</a>
    <button type="submit" class="btn btn-warning">Salvar</button>
</form>

<?php require_once('rodape.php'); ?>
