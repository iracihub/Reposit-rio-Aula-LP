<?php
$conn = mysqli_connect("localhost", "root", "", "cursos_online");

if (!$conn) {
    die("Erro na conexão: " . mysqli_connect_error());
}
?>


