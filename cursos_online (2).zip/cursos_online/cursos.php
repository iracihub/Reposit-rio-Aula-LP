
<?php
require_once('cabecalho.php');
require_once('conexao.php');    

$sql = "SELECT * FROM cursos";
$resultado = mysqli_query($conn, $sql);

if (!$resultado) {
    die("Erro na consulta: " . mysqli_error($conn));
}
?>

<h2>Cursos</h2>

<a href="novo_curso.php" class="btn btn-success mb-3">Novo Registro</a>

<table class="table table-hover table-striped">
<thead>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Descrição</th>
        <th>Carga Horária</th>
        <th>Ativo</th>
        <th>Ações</th>
    </tr>
</thead>

<tbody>
<?php while ($r = mysqli_fetch_assoc($resultado)): ?>

<tr>
    <td><?= $r['id_curso'] ?></td>
    <td><?= $r['nome'] ?></td>
    <td><?= $r['descricao'] ?></td>
    <td><?= $r['carga_horaria'] ?></td>
    <td><?= $r['ativo'] ? 'Sim' : 'Não' ?></td>

    <td class="d-flex gap-2">

        <a href="consultar_curso.php?id=<?= $r['id_curso'] ?>" 
           class="btn btn-sm btn-info">
           Consultar
        </a>

    </td>
</tr>

<?php endwhile; ?>
</tbody>
</table>

<?php
require_once('rodape.php');
?>


