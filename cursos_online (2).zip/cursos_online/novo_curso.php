
<?php
require_once('cabecalho.php');
require_once('conexao.php');
?>

<h2>Novo Curso</h2>

<form method="post">

    <div class="mb-3">
        <label>Nome do Curso</label>
        <input type="text" name="nome" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Descrição</label>
        <input type="text" name="descricao" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Carga Horária</label>
        <input type="number" name="carga_horaria" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Cadastrar</button>
    
    <a href="cursos.php" class="btn btn-secondary">Voltar</a>

</form>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $carga = $_POST['carga_horaria'];

    $data = date('Y-m-d');

    $sql = "INSERT INTO cursos (nome, descricao, carga_horaria, data_cadastro)
            VALUES ('$nome', '$descricao', '$carga', '$data')";

    if (mysqli_query($conn, $sql)) {
        echo "<p>Curso cadastrado com sucesso!</p>";
    } else {
        echo "Erro: " . mysqli_error($conn);
    }
}
?>

<?php require_once('rodape.php'); ?>
