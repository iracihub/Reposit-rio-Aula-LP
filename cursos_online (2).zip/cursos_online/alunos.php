<?php
require_once('cabecalho.php');
require_once('conexao.php');    

try{
    $sql = "SELECT * FROM alunos";
    $resultado = mysqli_query($conn, $sql);
} catch(Exception $e){
    echo "Erro: ".$e->getMessage();
}
?>

<h2>Alunos</h2>
<a href="novo_aluno.php" class="btn btn-success mb-3">Novo Registro</a>

<table class="table table-hover table-striped">
<thead>
<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Email</th>
    <th>Data Cadastro</th>
    <th>Ações</th>
</tr>
</thead>

<tbody>
<?php while ($r = mysqli_fetch_assoc($resultado)): ?>
<tr>
    <td><?= $r['id_aluno'] ?></td>
    <td><?= $r['nome'] ?></td>
    <td><?= $r['email'] ?></td>
    <td><?= $r['data_cadastro'] ?></td>

    <td class="d-flex gap-2">
        <a href="alterar_aluno.php?id=<?= $r['id_aluno'] ?>" class="btn btn-sm btn-warning">Editar</a>
        <a href="consultar_aluno.php?id=<?= $r['id_aluno'] ?>" class="btn btn-sm btn-info">Consultar</a>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

<?php require_once('rodape.php'); ?>
