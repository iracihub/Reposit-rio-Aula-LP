<?php require_once('cabecalho.php'); ?>

<h2>Bem-vindo ao Sistema de Cursos Online</h2>

<?php require_once('rodape.php'); ?>
