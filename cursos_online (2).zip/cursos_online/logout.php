
<?php
session_start();

// Destrói a sessão
session_destroy();

// Redireciona para o login ou index
header("Location: index.php");
exit;
?>
