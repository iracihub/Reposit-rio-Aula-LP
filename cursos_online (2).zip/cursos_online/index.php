
<?php
require_once('cabecalho.php');
?>

<h1>Sistema de Cursos Online</h1>

<div class="container mt-4">

    <div class="list-group">

        <a href="alunos.php" class="list-group-item list-group-item-action">
            📚 Alunos
        </a>

        <a href="cursos.php" class="list-group-item list-group-item-action">
            🎓 Cursos
        </a>

        <a href="professores.php" class="list-group-item list-group-item-action">
            👨‍🏫 Professores
        </a>

        <a href="matriculas.php" class="list-group-item list-group-item-action">
            📝 Matrículas
        </a>

    </div>

</div>

<?php
require_once('rodape.php');
?>
