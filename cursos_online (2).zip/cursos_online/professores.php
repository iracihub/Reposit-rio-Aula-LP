
<?php
require_once('cabecalho.php');
require_once('conexao.php');

$sql = "SELECT * FROM professores";
$resultado = mysqli_query($conn, $sql);

if (!$resultado) {
    die("Erro: " . mysqli_error($conn));
}
?>

<h2>Professores</h2>

<a href="novo_professor.php" class="btn btn-success mb-3">Novo Registro</a>


<table class="table table-hover table-striped">
<thead>
<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Email</th>
    <th>Especialidade</th>
    <th>Ações</th>
</tr>
</thead>

<tbody>
<?php if (mysqli_num_rows($resultado) > 0): ?>

    <?php while ($r = mysqli_fetch_assoc($resultado)): ?>
    <tr>
        <td><?= $r['id_professor'] ?></td>
        <td><?= $r['nome'] ?></td>
        <td><?= $r['email'] ?></td>
        <td><?= $r['especialidade'] ?></td>

    
    
<td class="d-flex gap-2">

    <a href="alterar_professor.php?id=<?= $r['id_professor'] ?>" 
       class="btn btn-sm btn-warning">
        Editar
    </a>

    <a href="consultar_professor.php?id=<?= $r['id_professor'] ?>" 
   class="btn btn-sm btn-info">
   Consultar
    </a>


</td>

    </tr>
    <?php endwhile; ?>

<?php else: ?>
    <tr>
        <td colspan="5">Nenhum professor encontrado</td>
    </tr>
<?php endif; ?>
</tbody>

</table>

<?php require_once('rodape.php'); ?>
