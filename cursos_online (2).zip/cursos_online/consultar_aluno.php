
<?php
require_once('cabecalho.php');
require_once('conexao.php');

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $sql = "SELECT * FROM alunos WHERE id_aluno = $id";
    $resultado = mysqli_query($conn, $sql);

    if ($r = mysqli_fetch_assoc($resultado)) {
?>

<h2>Consultar Aluno</h2>

<p><strong>ID:</strong> <?= $r['id_aluno'] ?></p>
<p><strong>Nome:</strong> <?= $r['nome'] ?></p>
<p><strong>Email:</strong> <?= $r['email'] ?></p>
<p><strong>Data Cadastro:</strong> <?= $r['data_cadastro'] ?></p>

<a href="alunos.php" class="btn btn-secondary">Voltar</a>

<?php
    } else {
        echo "Aluno não encontrado.";
    }

} else {
    echo "ID não informado.";
}
?>

<?php require_once('rodape.php'); ?>
